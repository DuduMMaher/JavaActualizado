package guia12extra4;

/**
 *
 * @author CASA
 */
public class Guia12Extra4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
